%%%%%%%%%%Main Setup%%%%%%%%%%%%%%%%%%%%%%%%%%%
L=5; K=3; N1=1; %%% #RRH:L, #user: K, #antenna: N1 
delta=1;   %normized noise variance
P=10^(0)*ones(1,L); % P: power constraints
Q=3;   % QoS requirements  
r=(10^(Q/10));%%%%all the MU has the same QoS requirements 
epsilon=0.1; %%%Outage Probability
RRH_set=[1:L];   %A_set: active RRH set, 
R=3; % # Channel Coefficients that Can not be Obtained for Each MU
TT=50;  % # Iterations for the Algorithms
tauu=0.01;  % estimation errors

load('D.mat');
load('H.mat'); 
load('W_DC_recoder.mat');
load('H_probability.mat')
load('H_DC.mat');


[Omega1, Omega2]=CompressiveCSI(D, R);   %%%%% Determine the Set Omega;

S2=10^3; % # Samples for the Stochastic DC Programming
S1=5*10^2;
%S1=0;
%H_samples_DC=samples(H, D, Omega1, Omega2, N1, S1, tauu); %Generate S2 Samples for Stochastic DC Programming
load('H_samples_DC');
%H_samples_DC=H_probability;

%%%%%%%%Scenario Approach%%%%%%%%%%%%%%%%%
for cc=1:TT
W=W_DC_recoder(:,:,cc);
Estimated_DC_temp=0;
for tt=1:S2+S1
    if tt<=S2
H=H_DC(:,:,tt,cc);
    else
        H=H_samples_DC(:,:,tt-S2);
    end
counter_temp=0;
     for k=1:K        %%%%%%%%%QoS Constraints
        if norm([H(:,k)'*W, delta],'fro')<=sqrt(1+1/r)*abs(H(:,k)'*W(:,k))
            counter_temp=counter_temp+1;
        end  
     end
     if counter_temp==3
Estimated_DC_temp=Estimated_DC_temp+1; 
     end
end
Probability_DC(cc)=Estimated_DC_temp/(S2+S1);
end


plot([1:TT],Probability_DC,'b--', 'LineWidth',1.5, 'MarkerSize',8); %Stochastic DC Programming: Bernstein Initial
hold on;
xlim([1,TT])

plot([1:TT],max(Probability_DC)*ones(1,TT),'b--', 'LineWidth',1.5, 'MarkerSize',8); %Stochastic DC Programming: Bernstein Initial
hold on;

plot([1:TT],min(Probability_DC)*ones(1,TT),'b--', 'LineWidth',1.5, 'MarkerSize',8); %Stochastic DC Programming: Bernstein Initial
hold on;

