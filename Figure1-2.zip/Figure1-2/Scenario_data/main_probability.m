%%%%%%%%%%Main Setup%%%%%%%%%%%%%%%%%%%%%%%%%%%
L=5; K=3; N1=1; %%% #RRH:L, #user: K, #antenna: N1 
delta=1;   %normized noise variance
P=10^(0)*ones(1,L); % P: power constraints
Q=3;   % QoS requirements  
r=(10^(Q/10));%%%%all the MU has the same QoS requirements 
epsilon=0.1; %%%Outage Probability
RRH_set=[1:L];   %A_set: active RRH set, 
R=3; % # Channel Coefficients that Can not be Obtained for Each MU
TT=50;  % # Iterations for the Algorithms
tauu=0.01;  % estimation errors

load('D.mat');
load('H.mat'); 
load('W_Sceanrio_recoder.mat');
load('H_Scenario.mat');

[Omega1, Omega2]=CompressiveCSI(D, R);   %%%%% Determine the Set Omega;

S2=10^4; % # Samples for the Stochastic DC Programming
%H_samples_DC=samples(H, D, Omega1, Omega2, N1, S2, tauu); %Generate S2 Samples for Stochastic DC Programming
%load('H_samples_DC');
H_samples_DC=H_Scenario;

%%%%%%%%Scenario Approach%%%%%%%%%%%%%%%%%
for cc=1:TT
W=W_Sceanrio_recoder(:,:,cc);
Estimated_DC_temp=0;
for tt=1:S2
H=H_samples_DC(:,:,tt);
counter_temp=0;
     for k=1:K        %%%%%%%%%QoS Constraints
        if norm([H(:,k)'*W, delta],'fro')<=sqrt(1+1/r)*abs(H(:,k)'*W(:,k))
            counter_temp=counter_temp+1;
        end  
     end
     if counter_temp==3
Estimated_DC_temp=Estimated_DC_temp+1; 
     end
end
Probability_Scenario(cc)=Estimated_DC_temp/(S2);
end


plot([1:TT],Probability_Scenario,'b--', 'LineWidth',1.5, 'MarkerSize',8); %Stochastic DC Programming: Bernstein Initial
hold on;
xlim([1,TT]);

plot([1:TT],max(Probability_Scenario)*ones(1,TT),'b--', 'LineWidth',1.5, 'MarkerSize',8); %Stochastic DC Programming: Bernstein Initial
hold on;

plot([1:TT],min(Probability_Scenario)*ones(1,TT),'b--', 'LineWidth',1.5, 'MarkerSize',8); %Stochastic DC Programming: Bernstein Initial
hold on;
