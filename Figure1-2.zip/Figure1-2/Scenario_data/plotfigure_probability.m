load('Probability_Scenario.mat');

plot([1:length(Probability_Scenario)],Probability_Scenario,'b--o','LineWidth',1.5, 'MarkerSize',8); %Bernstein Approximation
hold on;

h=legend('Benchmark: Full CSI', 'Stochastic DC Programming','Fixed One','Fixed Two', 'fontsize',12,'fontweight','b','fontname','helvetica');
xlabel('Iteration','fontsize',14,'fontweight','b','fontname','helvetica');
ylabel('Total Transmit Power [dBm]','fontsize',14,'fontweight','b','fontname','helvetica');