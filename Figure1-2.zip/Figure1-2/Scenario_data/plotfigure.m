TT=50;

load('TotalPower_Scenario.mat');
TotalPower_Scenario=TotalPower_Scenario([1:TT]);

plot([1:TT],10*log10(TotalPower_Scenario.*1000),'b--o','LineWidth',1.5, 'MarkerSize',8); %Bernstein Approximation
hold on;

% plot([1:TT],10*log10(max(TotalPower_Scenario).*1000)*ones(1,TT),'b--o','LineWidth',1.5, 'MarkerSize',8); %Bernstein Approximation
% hold on;
% 
% plot([1:TT],10*log10(min(TotalPower_Scenario).*1000)*ones(1,TT),'b--o','LineWidth',1.5, 'MarkerSize',8); %Bernstein Approximation
% hold on;

xlim([1 TT]);
%h=legend('Benchmark: Full CSI', 'Stochastic DC Programming','Fixed One','Fixed Two', 'fontsize',12,'fontweight','b','fontname','helvetica');
xlabel('Replication','fontsize',14,'fontweight','b','fontname','helvetica');
ylabel('Total Transmit Power [dBm]','fontsize',14,'fontweight','b','fontname','helvetica');