save('TotalPower_Bernstein.mat','TotalPower_Bernstein');
save('TotalPower_DC.mat','TotalPower_DC');
save('TotalPower_DC_fixed.mat','TotalPower_DC_fixed');

save('H_samples_DC.mat','H_samples_DC');
save('kappa_index.mat','kappa_index');

save('W_cvx.mat','W_cvx');
save('W_cvx_fixed.mat','W_cvx_fixed');

save('W_DC_fixed.mat','W_DC_fixed');
save('W_DC.mat','W_DC');
save('W_Bernstein.mat','W_Bernstein');

