clc; clear all;
load('W_DC.mat');
load('W_DC_fixed.mat');

W_DC=W_DC(:,:,[1:12]);
W_DC_fixed=W_DC_fixed(:,:,[1:25]);

for cc=1:length(W_DC)
    TotalPower_DC(cc)=norm(W_DC(:,:,cc),'fro')^2;
end

for cc=1:length(W_DC_fixed)
    TotalPower_DC_fixed(cc)=norm(W_DC_fixed(:,:,cc),'fro')^2;
end

plot([0:length(TotalPower_DC)-1],10*log10(TotalPower_DC.*1000),'r--','LineWidth',1.5, 'MarkerSize',8); %Bernstein Approximation
hold on;

plot([0:length(TotalPower_DC_fixed)-1],10*log10(TotalPower_DC_fixed.*1000),'b--','LineWidth',1.5, 'MarkerSize',8); %Bernstein Approximation
hold on;

plot([0:length(TotalPower_DC_fixed)-1],min(10*log10(TotalPower_DC.*1000))*ones(1,length(TotalPower_DC_fixed)),'g--','LineWidth',1.5, 'MarkerSize',8); %Bernstein Approximation
hold on;

plot([0:length(TotalPower_DC_fixed)-1],max(10*log10(TotalPower_DC.*1000))*ones(1,length(TotalPower_DC_fixed)),'g--','LineWidth',1.5, 'MarkerSize',8); %Bernstein Approximation
hold on;

h=legend('Benchmark: Full CSI', 'Stochastic DC Programming','Fixed One','Fixed Two', 'fontsize',12,'fontweight','b','fontname','helvetica');
xlabel('Iteration','fontsize',14,'fontweight','b','fontname','helvetica');
ylabel('Total Transmit Power [dBm]','fontsize',14,'fontweight','b','fontname','helvetica');