clc; clear all;
%%%%%%%%%%Main Setup%%%%%%%%%%%%%%%%%%%%%%%%%%%
L=5; K=3; N1=1; %%% #RRH:L, #user: K, #antenna: N1 
delta=1;   %normized noise variance
P=10^(0)*ones(1,L); % P: power constraints
Q=3;   % QoS requirements  
r=(10^(Q/10));%%%%all the MU has the same QoS requirements 
epsilon=0.1; %%%Outage Probability
RRH_set=[1:L];   %A_set: active RRH set, 
R=3; % # Channel Coefficients that Can not be Obtained for Each MU
TT=21;  % #Iterations for the Algorithms
tauu=0.01;  % estimation errors

load('D.mat');
load('H.mat'); 
load('W_DC.mat');
load('W_DC_fixed.mat');

W_DC=W_DC(:,:,[1:11]);
W_DC_fixed=W_DC_fixed(:,:,[1:25]);


[Omega1, Omega2]=CompressiveCSI(D, R);   %%%%% Determine the Set Omega;

S2=10^4; % # Samples for the Stochastic DC Programming
%H_probability=samples(H, D, Omega1, Omega2, N1, S2, tauu); %Generate S2 Samples for Stochastic DC Programming
 %load('H_samples_DC');
 %H_probability=H_samples_DC;
load('H_probability.mat');


%%%%%%%%Joint DC%%%%%%%%%%%%%%%%%
for cc=1:length(W_DC(1,1,:))
W=W_DC(:,:,cc);
Estimated_DC_temp=0;
for tt=1:S2
H=H_probability(:,:,tt);
counter_temp=0;
     for k=1:K        %%%%%%%%%QoS Constraints
        if norm([H(:,k)'*W, delta],'fro')<=sqrt(1+1/r)*abs(H(:,k)'*W(:,k))
            counter_temp=counter_temp+1;
        end  
     end
     if counter_temp==3
Estimated_DC_temp=Estimated_DC_temp+1; 
     end
end
Estimated_Probability(cc)=Estimated_DC_temp/(S2);
end

%%%%%%%%Fixed DC%%%%%%%%%%%%%%%%%
for cc=1:length(W_DC_fixed(1,1,:))
W=W_DC_fixed(:,:,cc);
Estimated_DC_fixed_temp=0;
for tt=1:S2
H=H_probability(:,:,tt);
counter_temp=0;
     for k=1:K        %%%%%%%%%QoS Constraints
        if norm([H(:,k)'*W, delta],'fro')<=sqrt(1+1/r)*abs(H(:,k)'*W(:,k))
            counter_temp=counter_temp+1;
        end  
     end
     if counter_temp==3
Estimated_DC_fixed_temp=Estimated_DC_fixed_temp+1; 
     end
end
Estimated_fixed_Probability(cc)=Estimated_DC_fixed_temp/(S2);
end


plot([0:length(W_DC(1,1,:))-1],Estimated_Probability,'r--', 'LineWidth',1.5, 'MarkerSize',8); %Stochastic DC Programming: Bernstein Initial
hold on;
plot([0:length(W_DC_fixed(1,1,:))-1],Estimated_fixed_Probability,'b--', 'LineWidth',1.5, 'MarkerSize',8); %Stochastic DC Programming: Bernstein Initial
hold on;

plot([0:length(W_DC_fixed)-1],max(Estimated_Probability)*ones(1,length(W_DC_fixed)),'g--','LineWidth',1.5, 'MarkerSize',8); %Bernstein Approximation
hold on;
% plot([0:length(W_DC_fixed)-1],min(Estimated_Probability)*ones(1,length(W_DC_fixed)),'g--','LineWidth',1.5, 'MarkerSize',8); %Bernstein Approximation
% hold on;
plot([0:length(W_DC_fixed)-1],0.8993*ones(1,length(W_DC_fixed)),'b--', 'LineWidth',1.5, 'MarkerSize',8); %Stochastic DC Programming: Bernstein Initial
hold on;


xlabel('Iteration','fontsize',14,'fontweight','b','fontname','helvetica');
ylabel('Probability Constraint','fontsize',14,'fontweight','b','fontname','helvetica');

